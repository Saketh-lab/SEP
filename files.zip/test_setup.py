#!/usr/bin/env python3
"""
Quick test script to verify your API key setup works
"""

import os
from dotenv import load_dotenv

load_dotenv()

print("=" * 50)
print("🔍 API Key Setup Test")
print("=" * 50)

USE_XAI = os.getenv("USE_XAI", "false").lower() == "true"
USE_GROQ = os.getenv("USE_GROQ", "false").lower() == "true"

if USE_XAI:
    print("\n✅ Using: xAI (Grok)")
    xai_key = os.getenv("XAI_API_KEY")
    if xai_key:
        print(f"   Key found: {xai_key[:10]}...{xai_key[-4:]}")
        print("   Model: grok-beta")
        print("   Status: ✅ Ready to go!")
    else:
        print("   Status: ❌ XAI_API_KEY not found")
        print("\n   Fix: Add to .env file:")
        print("   XAI_API_KEY=xai-your-key-here")
        print("   USE_XAI=true")
elif USE_GROQ:
    print("\n✅ Using: GROQ")
    groq_key = os.getenv("GROQ_API_KEY")
    if groq_key:
        print(f"   Key found: {groq_key[:10]}...{groq_key[-4:]}")
        print("   Status: ✅ Ready to go!")
    else:
        print("   Status: ❌ GROQ_API_KEY not found")
        print("\n   Fix: Add to .env file:")
        print("   GROQ_API_KEY=gsk-your-key-here")
        print("   USE_GROQ=true")
else:
    print("\n✅ Using: OpenAI")
    openai_key = os.getenv("OPENAI_API_KEY")
    if openai_key:
        print(f"   Key found: {openai_key[:7]}...{openai_key[-4:]}")
        print("   Status: ✅ Ready to go!")
    else:
        print("   Status: ❌ OPENAI_API_KEY not found")
        print("\n   Fix: Add to .env file:")
        print("   OPENAI_API_KEY=sk-your-key-here")

print("\n" + "=" * 50)
print("\nIf you see ✅ Ready to go!, run:")
print("   python app_a16z.py")
print("=" * 50)
