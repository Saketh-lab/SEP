# 🎯 READY TO GO - 2 COMMANDS

Your xAI API key is already configured in the `.env` file!

## Step 1: Install
```bash
pip install -r requirements.txt
```

## Step 2: Run
```bash
python app_a16z.py
```

**Opens at:** http://localhost:7860

---

## ✅ What's Already Set Up:

✓ `.env` file created with your xAI key
✓ Using Grok model (xAI's LLM)
✓ 30 a16z portfolio companies loaded
✓ Sample pitch pre-loaded for demo
✓ All code ready to run

---

## 🧪 Optional: Test Your Setup

```bash
python test_setup.py
```

Should say: "✅ Ready to go!"

---

## 🚀 For Your Hackathon Demo:

1. Run the app
2. The sample pitch is already loaded
3. Click "Submit"
4. Show the evaluation scores
5. Point out the unique a16z features:
   - Technical Vision score
   - Network Effects analysis
   - Contrarian Insight evaluation
   - Portfolio fit section

---

## 📁 Files You Have:

- `app_a16z.py` - Main Gradio interface
- `evaluator_a16z.py` - Evaluation logic
- `a16z_examples.json` - 30 portfolio companies
- `.env` - Your xAI API key (already configured)
- `test_setup.py` - Test script
- Sample pitches in `sample_pitches/` folder

---

That's it! Your evaluator is ready to run. 🎉
